﻿namespace Infrastruction
{
    public enum CarStatus
    {
        Free = 0,
        Busy = 1
    }
}